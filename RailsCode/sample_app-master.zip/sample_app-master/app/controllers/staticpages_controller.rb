class StaticpagesController < ApplicationController
  def home
  end

  def help
  end
end
