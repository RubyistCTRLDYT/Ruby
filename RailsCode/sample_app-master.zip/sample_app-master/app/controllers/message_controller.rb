class MessageController < ApplicationController
  #
  def hello
  end
end
